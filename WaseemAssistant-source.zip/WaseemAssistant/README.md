# Waseem Assistant for Android

A native Kotlin starter project for an Android voice assistant with a futuristic dark-blue UI, text-to-speech replies, Android speech recognition, and a set of safe phone actions.

## Included now
- Speak using Android's speech-recognition UI.
- Spoken replies using Android TextToSpeech.
- Tell time/date.
- Open Settings, Wi-Fi settings, Bluetooth settings, YouTube, Google, WhatsApp, camera (package availability varies), and phone dialer.
- `call <number>` opens the dialer with the number filled in. The user must confirm the call.
- A scaffold service and UI button for future wake-word integration.

## Important limitations
This is a **source project**, not a prebuilt APK. It has not been compiled or tested on a device in this environment.
- "Hey Waseem" always-on wake-word detection is **not active yet**. Android does not provide a universal always-listening wake phrase API for ordinary apps. Add a wake-word engine such as Picovoice Porcupine, configure its SDK/access key and a custom wake-word model, and test foreground microphone behavior on the target Android version.
- AI chat is not connected yet. Add a backend or API integration and keep the API key on the server. Do not embed a secret API key in the APK.
- Opening apps depends on whether those apps are installed and on Android package visibility rules.
- Android may restrict microphone foreground services while the app is in the background. Users must explicitly grant permissions.
- The app intentionally does not silently place phone calls, toggle restricted system settings, or continuously record audio.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `WaseemAssistant` folder.
3. Allow Android Studio to install the required Android SDK (compile SDK 35) and Gradle components.
4. Use **Build > Build APK(s)**.
5. Find the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.

Or use the included GitHub Actions workflow: push this folder to a GitHub repository and run the workflow to build and upload a debug APK artifact.

## Suggested next development steps
1. Add real wake-word detection for "Hey Waseem" using a supported engine and a custom model.
2. Add an AI backend for general questions, with a server-side API key.
3. Add user-configurable commands and permission-aware actions.
4. Test on a physical Android phone, especially Android 14/15 microphone restrictions.
