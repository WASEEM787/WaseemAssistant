package com.waseem.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var output: TextView
    private lateinit var commandInput: EditText
    private var ttsReady = false
    private val micRequest = 201
    private val speechRequest = 202

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        window.statusBarColor = android.graphics.Color.rgb(3, 10, 28)
        window.navigationBarColor = android.graphics.Color.rgb(3, 10, 28)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(android.graphics.Color.rgb(3, 10, 28))
        }
        val title = TextView(this).apply {
            text = "W A S E E M"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(78, 210, 255))
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL AI ASSISTANT"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.LTGRAY)
        }
        output = TextView(this).apply {
            text = "Systems ready. Tap the microphone and say a command."
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(8, 32, 8, 32)
        }
        commandInput = EditText(this).apply {
            hint = "Type a command..."
            setHintTextColor(android.graphics.Color.GRAY)
            setTextColor(android.graphics.Color.WHITE)
            setSingleLine(true)
        }
        val mic = makeButton("🎙  SPEAK")
        mic.setOnClickListener { listen() }
        val run = makeButton("RUN COMMAND")
        run.setOnClickListener { handleCommand(commandInput.text.toString()) }
        val wake = makeButton("ENABLE WAKE SERVICE")
        wake.setOnClickListener { enableWakeService() }
        val settings = makeButton("APP SETTINGS")
        settings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")))
        }

        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(commandInput, matchWrap())
        root.addView(mic, matchWrap())
        root.addView(run, matchWrap())
        root.addView(wake, matchWrap())
        root.addView(settings, matchWrap())
        setContentView(root)
        requestMicPermission()
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        textSize = 14f
        setTextColor(android.graphics.Color.rgb(78, 210, 255))
        setBackgroundColor(android.graphics.Color.rgb(10, 35, 64))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply {
        setMargins(0, 6, 0, 6)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
            ttsReady = true
        }
    }

    private fun requestMicPermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
        }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestMicPermission()
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a command for Waseem")
        }
        try { startActivityForResult(intent, speechRequest) }
        catch (_: Exception) { respond("Speech recognition is not available on this phone.") }
    }

    @Deprecated("Uses Android speech-recognition activity for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            commandInput.setText(spoken)
            handleCommand(spoken)
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim().lowercase(Locale.getDefault())
        if (command.isBlank()) { respond("Tell me what you would like me to do."); return }
        when {
            "time" in command -> respond("The time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
            "date" in command || "today" in command -> respond("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))
            "open settings" in command || command == "settings" -> {
                respond("Opening settings.")
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
            "open camera" in command || "camera" == command -> openApp("com.android.camera2", "Camera")
            "open youtube" in command || "youtube" == command -> openUrl("https://www.youtube.com", "Opening YouTube.")
            "open google" in command || "search google" in command -> openUrl("https://www.google.com", "Opening Google.")
            "open whatsapp" in command || "whatsapp" == command -> openApp("com.whatsapp", "WhatsApp")
            "open phone" in command || "dialer" in command -> {
                respond("Opening phone dialer.")
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")))
            }
            "call " in command -> {
                val number = raw.substringAfter("call ", "").trim()
                if (number.isNotBlank()) {
                    respond("Opening the dialer for $number. Please confirm the call on screen.")
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
                } else respond("Please say the phone number.")
            }
            "bluetooth" in command -> {
                respond("Opening Bluetooth settings.")
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            }
            "wifi" in command -> {
                respond("Opening Wi-Fi settings.")
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            }
            "help" in command || "what can you do" in command ->
                respond("I can tell time and date, open Settings, Wi-Fi, Bluetooth, YouTube, Google, WhatsApp, the camera, and the phone dialer. I can also prepare a call in the dialer.")
            else -> respond("I heard: $raw. For full AI answers, connect an AI API key in the next version. Try saying help.")
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            respond("Opening $label.")
            startActivity(launch)
        } else respond("$label is not installed or its app launch is unavailable.")
    }

    private fun openUrl(url: String, message: String) {
        respond(message)
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun respond(message: String) {
        output.text = message
        if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "waseem_reply")
    }

    private fun enableWakeService() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestMicPermission()
            respond("Please grant microphone permission first.")
            return
        }
        respond("Wake service setup is included as a placeholder. Always-on Hey Waseem detection needs a wake-word engine and microphone foreground-service configuration. This starter does not yet listen continuously.")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
