package com.waseem.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

/**
 * Safe scaffold for a future wake-word foreground service.
 * This intentionally does not record audio continuously.
 * Add a licensed wake-word engine (for example, Porcupine) and
 * obtain its access key before enabling always-on detection.
 */
class WakeService : Service() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "waseem_assistant", "Waseem Assistant",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "waseem_assistant")
                .setContentTitle("Waseem Assistant")
                .setContentText("Assistant service scaffold")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Waseem Assistant")
                .setContentText("Assistant service scaffold")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
        }
        startForeground(1001, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Intentionally no continuous microphone capture until wake-word engine is configured.
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
